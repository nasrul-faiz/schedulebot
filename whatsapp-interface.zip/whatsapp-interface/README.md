# Whatsapp interface 

A Pen created on CodePen.

Original URL: [https://codepen.io/vlrprbttst/pen/dYPwbX](https://codepen.io/vlrprbttst/pen/dYPwbX).

Whatsapp interface in html and css with material design style. see more and have a laugh at www.wutsapp.net